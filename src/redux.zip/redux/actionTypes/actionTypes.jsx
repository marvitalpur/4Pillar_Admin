export default class ActionTypes {
   // USER TYPES
    static SIGNUP = "SIGNUP";
    static LOGIN = "LOGIN";
    static LOGOUT = "LOGOUT";
    static ADMIN_LOGIN = "ADMIN_LOGIN";
}