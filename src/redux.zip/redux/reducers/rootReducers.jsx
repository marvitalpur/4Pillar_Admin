import { combineReducers } from "redux";
import authReducer from "./authentication";


const rootReducers = combineReducers({
    authReducer
});

export default rootReducers;


